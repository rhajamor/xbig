#/bin/bash

WORKING_DIR=`pwd`

java -jar jar/saxon-8.8.0.jar \
-o test/build/java/meta2java.log \
test/build/meta/meta.xml \
src/xsl/cpp2j/meta2java/meta2java.xslt \
outdir=$WORKING_DIR/test/build/java \
+config=src/xsl/cpp2j/config.xml \
+buildFile=test/build.xml
